package com.ppk.server.util;

import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.protobuf.ByteString;
import com.google.protobuf.Duration;
import com.google.protobuf.Timestamp;
import com.ppk.generated.Address;
import com.ppk.generated.StudentRequest;
import com.ppk.generated.StudentResponse;

@Service
public class DataHandler {
	
	private static final Logger logger=LoggerFactory.getLogger(DataHandler.class);
	
	public StudentResponse getStudentDetails(StudentRequest request) {
		try {
			logger.info("DataHandler : getStudentDetails : id="+request.getId());
			// super.getStudent(request, responseObserver);
			Address addr = Address.newBuilder().setStreet("1st Main road").setCity("Bangalore").setState("Karnataka")
					.setZipCode("560066").setCountry("India").build();

			// Create a specific Timestamp (e.g., January 1, 2020)
			Timestamp dob = Timestamp.newBuilder().setSeconds(1577836800) // seconds for January 1, 2020
					.setNanos(0).build();
			// Create a Timestamp representing the current time
			Timestamp now = Timestamp.newBuilder().setSeconds(System.currentTimeMillis() / 1000) // Current time in seconds
					.setNanos((int) (System.currentTimeMillis() % 1000) * 1_000_000) // Remaining milliseconds to nanoseconds
					.build();
			
			// Create a Duration for exam of 2.5 hours (9000 seconds)
	        Duration duration = Duration.newBuilder()
	                .setSeconds(9000) // 9000 seconds
	                .setNanos(0)     // 0 nanoseconds
	                .build();
			
			// Path to the file in the resources folder
			String fileName = "ppk.png"; // Change this to your actual file name
			// Use classloader to read the file from resources
			InputStream inputStream = DataHandler.class.getClassLoader().getResourceAsStream(fileName);
			// Read bytes from the input stream
			byte[] fileContent = inputStream.readAllBytes();
			ByteString fileByteString = ByteString.copyFrom(fileContent);

			StudentResponse studentResponse = StudentResponse.newBuilder().setId(request.getId()).setName("Prashanth K")
					//.setAddress(addr).setDob(dob).setEmails(0, "prashanthk@gmail.com").setEmails(1, "ppk@gmail.com")
					//.setIsHighschool(true).setPaidFee(12.38f)
					//.setProfilePicture(fileByteString)
					
					//.setGender(Gender.MALE).setJoinedDate(now).setExamDuration(duration)
					.build();
			
			return studentResponse;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
