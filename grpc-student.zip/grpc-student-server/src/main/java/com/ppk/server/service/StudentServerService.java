package com.ppk.server.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ppk.generated.StudentRequest;
import com.ppk.generated.StudentResponse;
import com.ppk.generated.StudentServiceGrpc;
import com.ppk.server.util.DataHandler;

import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

@GrpcService
public class StudentServerService extends StudentServiceGrpc.StudentServiceImplBase {

	private static final Logger logger=LoggerFactory.getLogger(StudentServerService.class);

	private final DataHandler dataHandler;

	public StudentServerService() {
		this.dataHandler = new DataHandler();
	}

	@Override
	public void getStudent(StudentRequest request, StreamObserver<StudentResponse> responseObserver) {
		logger.info("StudentServer : getStudent : id="+request.getId());
		//StudentResponse response = dataHandler.getStudentDetails(request);
		
		StudentResponse response = StudentResponse.newBuilder().setId(request.getId()).setName("Prashanth K").build();
		responseObserver.onNext(response);
		responseObserver.onCompleted();
	}
}
