package com.ppk.server;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import com.ppk.generated.StudentRequest;
import com.ppk.generated.StudentResponse;
import com.ppk.generated.StudentServiceGrpc.StudentServiceBlockingStub;

import net.devh.boot.grpc.client.inject.GrpcClient;

@SpringBootTest(properties = {
		"grpc.server.port=-1",
		"grpc.server.in-process-name=test",
		"grpc.client.in-process.address=in-process:test"})
	@SpringJUnitConfig(classes = GrpcServerApplicationTestConfiguration.class)
	@DirtiesContext
class GrpcStudentServerApplicationTests {

	@GrpcClient("in-process")
	private StudentServiceBlockingStub studentServiceBlockingStub;

	@Test
	@DirtiesContext
	public void test_get_post() {
		StudentRequest studentRequest = StudentRequest.newBuilder().setId(1).build();
		StudentResponse studentResponse = studentServiceBlockingStub.getStudent(studentRequest);

		assertNotNull(studentResponse);
		assertEquals("Prashanth K", studentResponse.getName());

		//assertNotNull(studentResponse.get);
		//assertEquals("Stephen King", studentResponse);
	}

}
